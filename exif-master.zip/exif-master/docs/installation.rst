############
Installation
############


************
Requirements
************

* Python 3.7+

******************
Installation Steps
******************

Install ``exif`` from the command line using pip::

   pip install exif

