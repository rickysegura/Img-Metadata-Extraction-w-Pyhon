#####
About
#####

************
Contributors
************

+ Tyler N. Thieding (Primary Author)
+ ArgiesDario (``delete_all()`` Method)
+ Justin Saunders (Support Signed Short Integers)
+ RKrahl (``setup.py`` Tweaks)
+ chbndrhnns (Allow Read File in Instantiation)
+ Rune Monzel (Example Code for Use with NumPy and OpenCV)
+ Alex Mykyta (Fix Value of ``SceneCaptureType.NIGHT_SCENE``)

***********
Development
***********

:Repository: https://www.gitlab.com/TNThieding/exif

*******
License
*******

.. literalinclude:: ../LICENSE
