.. include:: ../README.rst

.. toctree::
    :maxdepth: 2
    :hidden:

    about.rst
    api_reference.rst
    installation.rst
    release_notes.rst
    known_limitations.rst
    usage.rst
