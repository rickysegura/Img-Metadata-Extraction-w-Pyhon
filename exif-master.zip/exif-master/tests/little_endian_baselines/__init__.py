"""Baseline strings for test_little_endian tests."""

from .modify_ascii_same_len_hex import LITTLE_ENDIAN_MODIFY_BASELINE
