"""Baseline strings for test_delete_exif tests."""

from .delete_all_hex import DELETE_ALL_HEX_BASELINE
from .delete_ascii_tags_hex import DELETE_ASCII_TAGS_HEX_BASELINE
from .delete_geotag_hex import DELETE_GEOTAG_HEX_BASELINE
