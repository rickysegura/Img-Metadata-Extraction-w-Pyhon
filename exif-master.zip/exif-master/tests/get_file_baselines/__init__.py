"""Baseline strings for test_get_file tests."""

from .grand_canyon_thumbnail import GRAND_CANYON_THUMBNAIL
from .modified_noise_file_hex import MODIFIED_NOISE_FILE_HEX_BASELINE
