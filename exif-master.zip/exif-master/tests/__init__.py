﻿"""Test scripts for EXIF package."""
